PATH=$(pwd):$PATH
python -m unittest discover -p "*_tests*.py"
