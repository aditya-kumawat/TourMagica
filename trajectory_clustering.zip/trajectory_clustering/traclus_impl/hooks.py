'''
Created on Feb 8, 2016

@author: Alex
'''
def partitioned_points_hook(partitioned_points):
    pass

def clusters_hook(clusters):
    pass